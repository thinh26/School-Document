﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai6_1
{
    internal class Phone
    {
        protected string ma_so, nhan_hieu;
        protected int nam_san_xuat;
        protected double gia_nhap;

        public Phone(string ma_so, string nhan_hieu, double gia_nhap, int nam_san_xuat)
        {
            this.ma_so = ma_so;
            this.nhan_hieu = nhan_hieu;
            this.nam_san_xuat = nam_san_xuat;
            this.gia_nhap = gia_nhap;
        }
        public void Xuat()
        {
            Console.Write("Ma so: {0}\tNhan hieu: {1}\tGia nhap: {2}\tNam san xuat: {3}", ma_so, nhan_hieu, gia_nhap, nam_san_xuat);
        }
        public double Thue()
        {
            if (nhan_hieu == "Iphone" || nhan_hieu == "iphone")
                return gia_nhap * 0.1;
            else
                return gia_nhap * 0.05;
        }
    }
}
