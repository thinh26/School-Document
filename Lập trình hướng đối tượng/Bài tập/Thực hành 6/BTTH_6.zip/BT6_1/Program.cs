﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Bai6_1
{
    internal class Program
    {
        static void BT6_1()
        {
            //cac thanh phan thong tin cua mot smartphone
            string ma_so, nhan_hieu;
            int nam_san_xuat, dung_luong_bo_nho;
            double gia_nhap;
            //tao danh sach
            List <Smartphone> Sp = new List<Smartphone> ();
            Console.Write("Nhap so luong smartphone: ");
            int amount = int.Parse(Console.ReadLine());
            //Nhap tung smartphone mot
            for (int i= 0; i < amount; i++)
            {
                Console.Write("Nhap ma so: ");
                ma_so = Console.ReadLine();
                Console.Write("Nhap nhan hieu: ");
                nhan_hieu = Console.ReadLine();
                Console.Write("Nhap nam san xuat: ");
                nam_san_xuat = int.Parse(Console.ReadLine());
                Console.Write("Gia nhap: ");
                gia_nhap = double.Parse(Console.ReadLine());
                Console.Write("Nhap dung luong bo nho (GB): ");
                dung_luong_bo_nho = int.Parse(Console.ReadLine());

                Smartphone p = new Smartphone(ma_so, nhan_hieu, gia_nhap, nam_san_xuat, dung_luong_bo_nho);
                Sp.Add(p);
                p.Gia_ban();
            }
            //In danh sach
            for (int i = 0; i < Sp.Count; i++)
            {
                Console.Write("{0}- ", i + 1);
                Sp[i].Xuat();
            }
            //In smartphone co gia ban cao nhat
            /*for(int i = 0; i < Sp.Count;i++)
            {
                Sp.Max(Sp[i].dung_luong_bo_nho);
            }*/
            //Them mot smartphone vao mot vi tri trong danh sach
            Console.Write("Nhap vi tri can them: ");
            int Pos = int.Parse(Console.ReadLine());
            if(Pos < 0 || Pos > Sp.Count)
                Console.Write("Vi tri them khong hop le !");
            else
            {
                Console.Write("Nhap ma so: ");
                ma_so = Console.ReadLine();
                Console.Write("Nhap nhan hieu: ");
                nhan_hieu = Console.ReadLine();
                Console.Write("Nhap nam san xuat: ");
                nam_san_xuat = int.Parse(Console.ReadLine());
                Console.Write("Gia nhap: ");
                gia_nhap = int.Parse(Console.ReadLine());
                Console.Write("Nhap dung luong bo nho (GB): ");
                dung_luong_bo_nho = int.Parse(Console.ReadLine());

                Smartphone p1 = new Smartphone(ma_so, nhan_hieu, gia_nhap, nam_san_xuat, dung_luong_bo_nho);
                Sp.Insert(Pos, p1);
            }
            //In danh sach sau khi them
            Console.Write("\nDanh sach sau khi them:\n");
            for (int i = 0; i < Sp.Count; i++)
            {
                Console.Write("{0}- ", i + 1);
                Sp[i].Xuat();
            }
            //Dem smartphone co dung luong bo nho giong nhau
            Console.Write("\nNhap dung luong bo nho can dem (gb): ");
            int storage = int.Parse(Console.ReadLine());
            int count = 0;
            for(int i = 0; i < Sp.Count;i++)
            {
                if(Sp[i].dung_luong_bo_nho == storage)
                    count++;
            }
            Console.Write("\nCo {1} dien thoai co bo nho {0}GB", storage, count);
            /*In danh sach theo chieu giam dan cua gia nhap
            for (int i = 0; i < Sp.Count;i++)
                for (int j = i+1; j < Sp.Count; j++)
                {
                    if(Sp[i].gia_nhap > Sp[j].gia_nhap)
                    {
                        Smartphone p = new Smartphone(ma_so, nhan_hieu, gia_nhap, nam_san_xuat, dung_luong_bo_nho);
                        p = Sp[i];
                        Sp[i] = Sp[j];
                        Sp[j] = p;
                    }
                }*/
        }
        static void Main(string[] args)
        {
            BT6_1();
        }
    }
}