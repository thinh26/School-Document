﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai6_1
{
    internal class Smartphone : Phone
    {
        public int dung_luong_bo_nho { get; set; }
        protected double gia_ban;
        public Smartphone(string ma_so, string nhan_hieu, double gia_nhap, int nam_san_xuat, int dung_luong_bo_nho) : base(ma_so, nhan_hieu, gia_nhap, nam_san_xuat)
        {
            this.dung_luong_bo_nho = dung_luong_bo_nho;
        }
        public double Gia_ban()
        {
            int khoang_cach = 2021 - nam_san_xuat;
            if (khoang_cach <= 1)
                gia_ban = gia_nhap + (gia_nhap * 0.2) + Thue();
            if (khoang_cach > 1 || khoang_cach <= 3)
                gia_ban = gia_nhap + (gia_nhap * 0.1) + Thue();
            if (khoang_cach > 3)
                gia_ban = gia_nhap + (Thue() / 2);
            return gia_ban;
        }
        public new void Xuat()
        {
            base.Xuat();
            Console.Write("\tDung luong bo nho: {0}GB\tGia ban: {1}\n", dung_luong_bo_nho,Gia_ban());
        }
    }
}