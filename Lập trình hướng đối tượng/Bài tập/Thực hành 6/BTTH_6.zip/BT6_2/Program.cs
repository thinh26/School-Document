﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Bai6_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Doc file
            FileStream f = new FileStream("D:/C#/Bai_tap_tuan_13/Bai6_2/Hinh_tron.txt", FileMode.Open);
            StreamReader sr = new StreamReader(f);
            //Lay dang hinh va so hinh
            string dang_hinh = "Hinh tron";
            int n = int.Parse(sr.ReadLine());
            //Lay thong tin tung hinh mot va tinh chu vi, dien tich
            List<Circle> ce = new List<Circle>(n);
            for (int i = 0; i < n; i++)
            {
                double r = double.Parse(sr.ReadLine());
                Circle ci = new Circle(dang_hinh, r);
                ce.Add(ci);
                ci.Chu_vi();
                ci.Dien_tich();
            }
            //In danh sach ra man hinh
            foreach (Shape s in ce)
            {
                s.Xuat();
                Console.Write("\n");
            }
            //Tinh chi phi son mau
            Console.Write("\nNhap gia son: ");
            double cost = double.Parse(Console.ReadLine());
            foreach (Circle ci in ce)
                ci.Cost(cost);
            //In chi phi ra man hinh
            foreach (Circle ci in ce)
                ci.Xuat();
            //Xoa hinh tron co dien tich nho hon x
            Console.Write("\nNhap vao dien tich: ");
            double x = double.Parse(Console.ReadLine());
            int pos = -1;
            for(int i = 0; i < ce.Count; i++)
            {
                if (ce[i].Dien_tich() < x)
                    pos = i;
            }
            if (pos >= 0)
                ce.RemoveAt(pos);
            //In danh sach sau khi xoa
            foreach (Circle ci in ce)
                ci.Xuat();
            //Dem va xuat ra so luong hinh tron co chu vi bang dien tich
            int count = 0;
            for (int i = 0; i < ce.Count; i++)
            {
                if (ce[i].Chu_vi() == ce[i].Dien_tich())
                    count++;
            }
            if (count > 0)
            {
                Console.Write("\nSo hinh tron co chu vi bang dien tich la: {0}\n", count);
                for (int i = 0; i < ce.Count; i++)
                    if (ce[i].Chu_vi() == ce[i].Dien_tich())
                        ce[i].Xuat();
            }
            else /* if (count == 0) */ Console.Write("\nKhong co hinh tron ma chu vi bang dien tich trong danh sach !");
        }
    }
}
