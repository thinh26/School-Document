﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai6_2
{
    internal class Circle : Shape, IPaint
    {
        public double c = 200000;
        protected double radius; //Ban kinh hinh tron
        //Phuong thuc thiet lap
        public Circle(string ten_hinh, double r) : base(ten_hinh)
        {
            radius = r;
        }
        //Tinh chu vi (ghi de)
        public override double Chu_vi()
        {
            return Math.Round((2 * radius * Math.PI), 2);
        }
        //Tinh dien tich (ghi de)
        public override double Dien_tich()
        {
            return Math.Round((Math.Pow(radius, 2) * Math.PI), 2);
        }
        //Tinh chi phi son mau
        public double Cost(double c)
        {
            return Math.Round((c * Dien_tich()), 0);
        }
        //In ra man hinh
        public new void Xuat()
        {
            base.Xuat();
            Console.Write("\tChi phi son mau: {0}\n", Cost(c));
        }
    }
}
