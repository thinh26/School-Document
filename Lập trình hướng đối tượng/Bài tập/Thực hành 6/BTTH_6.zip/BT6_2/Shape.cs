﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai6_2
{
    internal class Shape
    {
        //thanh phan du lieu
        protected string ten_hinh;

        //phuong thuc thiet lap
        public Shape( string ten_hinh = "")
        {
            this.ten_hinh = ten_hinh;
        }
        //Tinh chu vi
        public virtual double Chu_vi()
        {
            return 0;
        }
        //Tinh dien tich
        public virtual double Dien_tich()
        {
            return 0;
        }
        //In thong tin ra man hinh
        public void Xuat()
        {
            Console.Write("Loai hinh: {0}\tChu vi: {1}\tDien tich: {2}", ten_hinh, Chu_vi(), Dien_tich());
        }
    }
}
