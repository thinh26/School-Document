﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai6_3
{
    internal class Xe
    {
        //Thanh phan du lieu
        protected string Loai_xe, Noi_dang_ky;
        protected long Gia_xe;
        //Phuong thuc nhap
        public Xe(string Lx, string Ndk, long Gx)
        {
            Loai_xe = Lx;
            Noi_dang_ky = Ndk;
            Gia_xe = Gx;
        }
        //Tinh gia ban
        public double Gia_ban()
        {
            if(Noi_dang_ky == "Ha Noi")
                return Gia_xe + (0.12 * Gia_xe);
            else
                return Gia_xe + (0.1 * Gia_xe);
        }
        //In ra man hinh
        public void Xuat()
        {
            Console.Write("Loai xe: {0}\tNoi dang ky: {1}", Loai_xe, Noi_dang_ky);
        }
    }
}
