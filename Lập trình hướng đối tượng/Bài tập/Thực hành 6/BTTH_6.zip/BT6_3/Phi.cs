﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai6_3
{
    internal interface Phi
    {
        public double Phi_truoc_ba(double phi_truoc_ba);
    }
}
