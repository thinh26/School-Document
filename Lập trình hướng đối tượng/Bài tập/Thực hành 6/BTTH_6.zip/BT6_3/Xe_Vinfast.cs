﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bai6_3
{
    internal class Xe_Vinfast : Xe, Phi
    {
        //Thanh phan du lieu
        int So_cho_ngoi;
        //Phuong thuc nhap
        public Xe_Vinfast(string Loai_xe, string Noi_dang_ky, long Gia_xe, int Scn) : base(Loai_xe, Noi_dang_ky, Gia_xe)
        {
            So_cho_ngoi = Scn;
        }
        //Tinh phi truoc ba
        public double Phi_truoc_ba(double phi_truoc_ba)
        {
            return phi_truoc_ba * Gia_xe;
        }
        //Tinh gia lan banh
        public double Gia_lan_banh(double phi_truoc_ba)
        {
            return Gia_ban() + Phi_truoc_ba(phi_truoc_ba);
        }
        //In ra man hinh
        public new void Xuat(double phi_truoc_ba)
        {
            base.Xuat();
            Console.Write("\tSo cho ngoi: {0}\tGia xe: {1} VND\tGia lan banh: {2} VND\n", So_cho_ngoi, Gia_ban(), Gia_lan_banh(phi_truoc_ba));
        }
    }
}
