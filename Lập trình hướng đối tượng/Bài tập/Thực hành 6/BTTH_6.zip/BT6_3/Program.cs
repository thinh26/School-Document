﻿using System;
using System.Collections.Generic;
using System.IO;

namespace Bai6_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Doc file
            FileStream f = new FileStream("D:/C#/Bai_tap_tuan_13/Bai6_3/Xe_Vinfast.txt", FileMode.Open);
            StreamReader sr = new StreamReader(f);
            //Lay luong xe
            int n = int.Parse(sr.ReadLine());
            //Lay thong tin tung xe
            List <Xe_Vinfast> vf = new List <Xe_Vinfast>(n); int i;
            const double phi_truoc_ba = 0.1;
            for(i = 0; i < n; i++)
            {
                string Loai_xe = sr.ReadLine();
                string Noi_dang_ky = sr.ReadLine();
                int So_cho_ngoi = int.Parse(sr.ReadLine());
                long Gia_xe = long.Parse(sr.ReadLine());
                Xe_Vinfast xvf = new Xe_Vinfast(Loai_xe, Noi_dang_ky, Gia_xe, So_cho_ngoi);
                vf.Add(xvf);
                xvf.Gia_lan_banh(phi_truoc_ba);
            }
            foreach (Xe_Vinfast xvf in vf)
            {
                xvf.Xuat(phi_truoc_ba);
            }
        }
    }
}
