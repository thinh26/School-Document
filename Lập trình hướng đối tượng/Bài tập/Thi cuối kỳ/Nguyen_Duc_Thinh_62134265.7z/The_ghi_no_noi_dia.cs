﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nguyen_Duc_Thinh_62134265
{
    internal class The_ghi_no_noi_dia : The, Giao_dich
    {
        double so_du, m, muc_toi_thieu;
        public The_ghi_no_noi_dia(int st, string ht, double sd, double tmh, double mth) : base(st,ht)
        {
            so_du = sd;
            m = tmh;
            muc_toi_thieu = mth;
        }
        public void Thanh_toan_mua_hang()
        {
            double ttmh;
            if (m < so_du)
                ttmh = (so_du - m);
            else
                Console.Write("Giao dich khong thanh cong !");
        }
        public double Phi_dich_vu(double so_du, double muc_toi_thieu)
        {
            if (so_du > muc_toi_thieu)
                return 5000;
            else
                return 12000;
        }
        public void Kiem_tra_so_du(double so_du, double muc_toi_thieu)
        {
            base.Xuat();
            Console.Write("\tNgay hien tai: {0}\tSo du: {1}\tPhi dich vu: {2}\n", DateTime.Now, so_du, Phi_dich_vu(so_du, muc_toi_thieu));
        }
    }
}
