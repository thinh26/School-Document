﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nguyen_Duc_Thinh_62134265
{
    internal interface Giao_dich
    {
        public double Phi_dich_vu(double so_du, double muc_toi_thieu);
    }
}
