﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nguyen_Duc_Thinh_62134265
{
    internal class The
    {
        int so_the; string ho_ten;
        public The (int st, string ht)
        {
            so_the = st;
            ho_ten = ht;
        }
        public void Xuat()
        {
            Console.Write("So the: {0}\tHo ten: {1}", so_the, ho_ten);
        }
    }
}
