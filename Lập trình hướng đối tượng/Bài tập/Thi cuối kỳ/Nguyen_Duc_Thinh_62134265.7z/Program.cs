﻿using System;
using System.IO;
using System.Collections.Generic;

namespace Nguyen_Duc_Thinh_62134265
{
    class Program
    {
        static void Main(string[] args)
        {
            FileStream fs = new FileStream("D:/Nguyen_Duc_Thinh_62134265/The_ghi_no_noi_dia.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            int n = int.Parse(sr.ReadLine());
            List<The_ghi_no_noi_dia> tgnnd = new List<The_ghi_no_noi_dia>(n);
            for(int i = 0; i < n; i++)
            {
                int so_the = int.Parse(sr.ReadLine());
                string ho_ten = sr.ReadLine();
                double so_du = double.Parse(sr.ReadLine());
                double tien_mua_hang = double.Parse(sr.ReadLine());
                double muc_toi_thieu = double.Parse(sr.ReadLine());
                The_ghi_no_noi_dia tnd = new The_ghi_no_noi_dia(so_the, ho_ten, so_du, tien_mua_hang, muc_toi_thieu);
                tnd.Thanh_toan_mua_hang();
                tnd.Kiem_tra_so_du(so_du, muc_toi_thieu);
            }
            foreach(The_ghi_no_noi_dia tnd in tgnnd)
            {
                if (tnd.Phi_dich_vu(so_du, muc_toi_thieu) == 12000)
                    tnd.Xuat();
            }
        }
    }
}
